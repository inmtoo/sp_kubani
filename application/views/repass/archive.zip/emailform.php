<p>Чтобы восстановить пароль, введите адрес электронной почты (email), указанный при регистрации. На этот адрес мы вышлем Вам письмо для восстановления доступа.</p>

<form action="/repass/getemail/" method="post">
	<div class="form-group">
		<label>Введите адрес электронной почты</label>
		<input type="email" name="logemail" class="form-control"/>
	</div>
	<input type="submit" class="btn btn-primary" name="send" value="Выслать" />
</form>