<h3>Системное сообщение:</h3>
<p><?php echo $data['sys_msg'];?></p>